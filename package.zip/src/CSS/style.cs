.Array_Data{
    display:inline-block;
  }