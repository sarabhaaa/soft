const Posts = () => {
    return (
        <div>
            <h1>This is Posts route</h1>
        </div>
    );

};
export default Posts;