import Grid_Component from "./Grid_Component";


const FormRow = () => {
    return (<Grid_Component></Grid_Component>
    );
}

export default FormRow;