const Index = () => {
    return (
        <div>
            <h1>This is index route</h1>
        </div>
    );
  

};
export default Index;