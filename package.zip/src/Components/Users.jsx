const Users = () => {
    return (
        <div>
            <h1>This is users route</h1>
        </div>
    );

};
export default Users;